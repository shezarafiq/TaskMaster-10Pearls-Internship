�
roslynCA1816,Dispose methods should call SuppressFinalize"�A method that is an implementation of Dispose does not call GC.SuppressFinalize; or a method that is not an implementation of Dispose calls GC.SuppressFinalize; or a method calls GC.SuppressFinalize and passes something other than this (Me in Visual Basic).(0�
roslynCA1822Mark members as static"�Members that do not access instance data or call instance methods can be marked as static. After you mark the methods as static, the compiler will emit nonvirtual call sites to these members. This can give you a measurable performance gain for performance-sensitive code.(0�
roslynCA1829;Use Length/Count property instead of Count() when available"hEnumerable.Count() potentially enumerates the sequence while a Length/Count property is a direct access.(05
roslynCS8603Possible null reference return.(0Q
roslynCS8625;Cannot convert null literal to non-nullable reference type.(09
roslynCA1825#Avoid zero-length array allocations(0�
roslynCS8618jNon-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.(0